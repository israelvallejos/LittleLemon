from django.urls import path
from . import views
from .models import Menu

urlpatterns = [
    path('', views.home, name="home"),
    path('menu/', views.menu, name='menu'),  # Update this line
    path('about/', views.about, name="about"),
    path('book/', views.book, name="book"),
    path('menu_item/<int:pk>/', views.display_menu_items, name="menu_item"),
    # Add the remaining URL path configurations here
]